SAX2 driver that uses XmlPull API to implement XMLReader.


